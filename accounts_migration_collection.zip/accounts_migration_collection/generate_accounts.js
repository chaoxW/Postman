const newman = require('newman');

newman.run({
    collection: require('./collections/accounts_migration.postman_collection.json'),
    reporters: 'cli',
    iterationData: './data/test.csv'
}).on('beforeDone', (error) => {
    if (error) {
        throw error;
    }
});

newman.run({
    collection: require('./collections/accounts_migration.postman_collection.json'),
    reporters: 'json-summary',
    iterationData: './data/test.csv'
});