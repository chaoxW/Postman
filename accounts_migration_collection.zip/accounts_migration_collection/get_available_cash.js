const newman = require('newman');
const Papa = require('papaparse')
const fs = require('fs');
let results = [];

newman.run({
    collection: require('./collections/get_available_cash.postman_collection.json'),
    reporters: 'cli',
    iterationData: './data/test.csv'
}).on('request', function (args) {
    const textDecoder = new TextDecoder();
    const resDecoded = textDecoder.decode(args.response?.stream);
    let res = resDecoded ? JSON.parse(resDecoded) : undefined;
    results.push(res?.availableCash?.toString());
    // console.log('resDecoded', results);
}).on('beforeDone', () => {
    updateCSVFile(results);
})

function updateCSVFile(availableCash) {
    fs.readFile('./data/DATA_CSV.csv', 'utf-8', (error, data) => {
        if (error) {
            throw error;
        }
        const jsonData = Papa.parse(data, { header: true });
        jsonData.data.map((item, index) => item.availableCash = availableCash ? availableCash[index] : null);
        const updatedCSV = Papa.unparse(jsonData.data);
        console.log(updateCSVFile);
        fs.writeFile('./updateCSV/UPDATED_CSV_CASH_AVAILABLE.csv', updatedCSV, (error) => {
            if (error) {
                throw error;
            }
            console.log('Updated Successfully!!');
        })
    });
}